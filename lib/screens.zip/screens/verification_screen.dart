import 'package:flutter/material.dart';

class AccountVerificationScreen extends StatelessWidget {
  const AccountVerificationScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // **TOP IMAGE & TEXT SECTION**
              Stack(
                children: [
                  Image.asset(
                    "assets/images/Lion.png", // Background Image
                    width: double.infinity,
                    height: 400,
                    fit: BoxFit.cover,
                  ),
                  // Centered "Welcome to Wild Guard" Text
                  Positioned(
                    top: 140, // Adjust position as needed
                    left: 0,
                    right: 0,
                    child: Column(
                      children: [
                        Text(
                          "Welcome to",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 30,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "Wild Guard",
                          style: TextStyle(
                            color: Color(0xFF9A5525),
                            fontSize: 45,
                            fontWeight: FontWeight.bold,
                            fontStyle: FontStyle.italic,
                            shadows: [
                              Shadow(
                                blurRadius: 5.0,
                                color: Colors.black,
                                offset: Offset(2.0, 2.0),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),

              // **ACCOUNT VERIFICATION CONTAINER (MOVED UP)**
              Transform.translate(
                offset: Offset(0, -90), // Moves the container upwards
                child: Container(
                  padding: EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Color(0xFF9A5525), // Theme color
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(40),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            "    Account Verification",
                            style: TextStyle(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(width: 8),
                          Image.asset(
                            'assets/icon/paw.png', // Paw icon path
                            width: 50,
                            height: 50,
                            color: Colors.white,
                          ),
                        ],
                      ),
                      SizedBox(height: 10),

                      Text(
                        "Please enter 4 digit code sent to your email.",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 20),

                      // **OTP INPUT FIELDS**
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: List.generate(
                          4,
                          (index) => Container(
                            width: 50,
                            height: 50,
                            margin: EdgeInsets.symmetric(horizontal: 8),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: TextField(
                              textAlign: TextAlign.center,
                              keyboardType: TextInputType.number,
                              maxLength: 1,
                              style: TextStyle(fontSize: 22),
                              decoration: InputDecoration(
                                counterText: "",
                                border: InputBorder.none,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),

                      // **VERIFY BUTTON**
                      ElevatedButton(
                        onPressed: () {
                          // Handle verification logic
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(
                            horizontal: 40,
                            vertical: 15,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        child: Text(
                          "Verify",
                          style: TextStyle(
                            color: Color(0xFF9A5525),
                            fontSize: 18,
                          ),
                        ),
                      ),
                      SizedBox(height: 10),

                      // **DIDN’T GET CODE?**
                      TextButton(
                        onPressed: () {
                          // Resend OTP action
                        },
                        child: Text(
                          "Didn’t get code?",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
